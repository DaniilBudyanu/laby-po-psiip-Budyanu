<?php
phpinfo();



echo 'Привет всем, это Лр21 </br>';
$Color = "green";
$Size='20px';
    $Text = "Скробот Валерия Валерьевна";

    echo '<div style="Color:'.$Color.'"><p style="font-size:'.$Size.';">'.$Text.'</p></div>';

$num_e=2.71828;
 echo "Число e равно $num_e </br>";

 $num_e1 = (float)$num_e;
 $num_e1 = (string)$num_e1;
 $num_e1 = (int)$num_e1;
 $num_e1 = (bool)$num_e1;
 echo "Преобразованное число $num_e1 </br>";

 echo "Номер строки: " . __LINE__;

?>