<?php 

include '1.html';
include '2.html';

?>