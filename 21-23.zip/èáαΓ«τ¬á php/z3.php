<?php 

$n = 'Скробот Валерия ';
$i = 0;
while ($i + $n):
    echo $n;
    $i++;
endwhile;

?>