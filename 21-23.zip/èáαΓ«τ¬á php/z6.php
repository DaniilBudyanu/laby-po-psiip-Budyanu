<?php 

function f($x, $y){
    $result = ((sqrt(abs($x-1)))-(sqrt(abs(pi()-$x))))/(((1+pow($x,2)))/(2+pow($y, 2))/4);
    return $result;
}

echo f(5, 7);

?>